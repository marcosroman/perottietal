# set the parameter 'oslom_undir_executable' to indicate the location of OSLOM/oslom_undir (once compiled) => either replace it here by its location or paste the executable (oslom_undir) in this folder
oslom2hierpartfolder=~/projects/perottietal/code/oslom2hierpart/minimal
#oslom_undir_executable=$oslom2hierpartfolder/oslom_undir
oslom_undir_executable=./oslom_undir
nspfolder=../nsps

